#!/bin/bash

current_directory=$(pwd)
echo "1. Current directory is" $current_directory
# sh set_env_variables.sh
make synseis
